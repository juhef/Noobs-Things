How to generate "icns" icon file
================================

In this directory run:

    $ iconutil -c icns Robomongo.iconset

File `Robomongo.icns` will be generated.
