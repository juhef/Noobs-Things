This is just a placeholder for `cmake`. 

Test source files are located in the same directory alongside the tested file in `robomongo/src/robomongo/` dir and sub-dirs.

e.g. 
```
...
RoboCrypt.cpp
RoboCrypt_test.cpp
...
StringOperations.cpp
StringOperations_test.cpp
...
```
