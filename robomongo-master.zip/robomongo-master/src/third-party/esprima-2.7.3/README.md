jquery/esprima
----------------
Esprima (esprima.org, BSD license) is a high performance, standard-compliant ECMAScript parser written in ECMAScript (also popularly known as JavaScript)

Origin:  
https://github.com/jquery/esprima

Robo path:  
https://github.com/Studio3T/robomongo/blob/master/src/robomongo/gui/resources/scripts/esprima.js
