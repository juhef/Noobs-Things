#define rbm_socket_t SOCKET
#define rbm_socket_invalid INVALID_SOCKET
