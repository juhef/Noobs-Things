#pragma once

namespace Robomongo
{
    void changeShellTimeoutDialog();
}
